<?php
include 'db.php';

// Proses simpan jika form dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['Nama_barang'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['jumlah_stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    $query = "INSERT INTO simulasibarang (Nama_barang, kategori, jumlah_stok, harga, tanggal_masuk)
              VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal')";
    mysqli_query($koneksi, $query);
}

// Ambil data barang dari database
$data = mysqli_query($koneksi, "SELECT * FROM simulasibarang");
?>

<!DOCTYPE html>
<html>
<head>

    <title>Inventaris Barang</title>
    <style>
        body {
            font-family: sans-serif;
            padding: 20px;
            background-color:rgb(231, 248, 232);
            background-position: center;
            
        }
        h2 {
            text-align: center;
        }
        form, table {
            width: 80%;
            margin: 20px auto;
        }
        input, select {
            padding: 8px;
            width: 100%;
        }
        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            border: none;
            color: white;
            cursor: pointer;
        }
        table {
            border-collapse: collapse;
        }
        th, td {
            padding: 8px 12px;
            border: 1px solid #aaa;
            text-align: center;
        }
        th {
            background-color: #eee;
        }
    </style>
</head>
<body>

<h2>Inventaris Barang</h2>


</form>

<!-- Tabel Tampilkan Barang -->
<table>
    <tr>
        <th>Nama Barang</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Harga</th>
        <th>Tanggal Masuk</th>
        <th>Aksi</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $row['Nama_barang']; ?></td>
            <td><?= $row['kategori']; ?></td>
            <td><?= $row['jumlah_stok']; ?></td>
            <td><?= $row['harga']; ?></td>
            <td><?= $row['tanggal_masuk']; ?></td>
            <td>
            <a href="edit.php?id=<?= $row['ID_barang']; ?>" style="color: blue;">Edit</a> |
            <a href="hapus.php?id=<?= $row['ID_barang']; ?>" onclick="return confirm('Yakin mau hapus data ini?')" style="color: red;">Hapus</a>
            </td>
        </tr>
       
    <?php } ?>
</table>
<br>
<div style="text-align: center; margin-top: 20px;">
  <a href="proses_tambah.php" style="padding: 8px 16px; background-color:rgb(255, 21, 21); color: white; text-decoration: none; border-radius: 4px;">Tambah Barang</a>
</div>
</body>
</html>
