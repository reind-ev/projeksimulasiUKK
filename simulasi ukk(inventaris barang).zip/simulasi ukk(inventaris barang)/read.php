<?php
include 'db.php';

$result = mysqli_query($conn, "SELECT * FROM simulasibarang");
?>

$query = "SELECT * FROM simulasibarang";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Barang</title>
    <style>
        table {
            width: 80%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #666;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #eee;
        }
    </style>
</head>
<body>

<h2 style="text-align: center;">Data Inventaris Barang</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Nama Barang</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Harga</th>
        <th>Tanggal Masuk</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['ID_barang']; ?></td>
            <td><?= $row['nama_barang']; ?></td>
            <td><?= $row['kategori_barang']; ?></td>
            <td><?= $row['jumlah_stok']; ?></td>
            <td><?= $row['harga_barang']; ?></td>
            <td><?= $row['tanggal_masuk']; ?></td>
        </tr>
    <?php } ?>

</table>

</body>
</html>
