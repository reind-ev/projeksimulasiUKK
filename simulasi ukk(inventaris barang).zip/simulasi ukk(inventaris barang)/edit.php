<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($koneksi, "SELECT * FROM simulasibarang WHERE id = '$id'");
    $data = mysqli_fetch_assoc($result);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['Nama_barang'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['jumlah_stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    $update = mysqli_query($koneksi, "UPDATE simulasibarang SET 
        Nama_barang='$nama',
        kategori='$kategori',
        jumlah_stok='$stok',
        harga='$harga',
        tanggal_masuk='$tanggal'
        WHERE id='$id'");

    if ($update) {
        header("Location: index.php");
    } else {
        echo "Gagal mengupdate data!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
</head>
<body>
    <h2>Edit Data Barang</h2>
    <form method="POST">
        <label>Nama Barang</label><br>
        <input type="text" name="Nama_barang" value="<?= $data['Nama_barang']; ?>"><br><br>

        <label>Kategori</label><br>
        <input type="text" name="kategori" value="<?= $data['kategori']; ?>"><br><br>

        <label>Stok</label><br>
        <input type="number" name="jumlah_stok" value="<?= $data['jumlah_stok']; ?>"><br><br>

        <label>Harga</label><br>
        <input type="text" name="harga" value="<?= $data['harga']; ?>"><br><br>

        <label>Tanggal Masuk</label><br>
        <input type="date" name="tanggal_masuk" value="<?= $data['tanggal_masuk']; ?>"><br><br>

        <button type="submit">Update</button>
        <a href="index.php">Kembali</a>
    </form>
</body>
</html>
