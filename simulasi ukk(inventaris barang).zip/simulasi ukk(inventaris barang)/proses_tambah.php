<?php
include 'db.php';

// Proses simpan data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['Nama_barang'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['jumlah_stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    $query = "INSERT INTO simulasibarang (Nama_barang, kategori, jumlah_stok, harga, tanggal_masuk)
              VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal')";

    $insert = mysqli_query($koneksi, $query);
    
    if ($insert) {
        header("Location: index.php");
        exit;
    } else {
        echo "Gagal menambahkan Data: " . mysqli_error($koneksi);
    }
} // ← Ini penutup if POST

// Ambil data barang
$result = mysqli_query($koneksi, "SELECT * FROM simulasibarang");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4">Tambah Barang</h2>

    <form method="POST" class="column mb-5">
        <div class="col-wd-6">
            <label class="form-label">Nama Barang</label>
            <input type="text" name="Nama_barang" class="form-control" required>
        </div>

        <div class="col-wd-6">
            <label class="form-label">Kategori</label>
            <input type="text" name="kategori" class="form-control" required>
        </div>
        
        <div class="col-wd-4">
            <label class="form-label">Stok</label>
            <input type="number" name="jumlah_stok" class="form-control" required>
        </div>

        <div class="col-wd-4">
            <label class="form-label">Harga</label>
            <input type="text" name="harga" class="form-control" required>
        </div>
        <div class="col-wd-4">
            <label class="form-label">Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" class="form-control" required>
        </div>
        <br>
        <div class="col-12">
            <button type="submit" class="btn btn-danger">ADD</button>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </div>
    </form>
</body>
</html>
