<?php
include 'db.php';

if (isset($_GET['ID_barang'])) {
    $id = $_GET['ID_barang'];
    $hapus = mysqli_query($koneksi, "DELETE FROM simulasibarang WHERE ID_barang = '$id'");

    if ($hapus) {
        header("Location: index.php");
    } else {
        echo "Gagal menghapus data!";
    }
}
?>
